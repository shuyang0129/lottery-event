// 獎項陣列 - 假資料
export const prizesDate = [
  {
    id: '5',
    prizeNum: 1,
    detailName: 'IPhone 11 64GB',
  },
  {
    id: '6',
    prizeNum: 2,
    detailName: '華為 HUAWEI P30 8GB+128GB',
  },
  {
    id: '7',
    prizeNum: 3,
    detailName: 'Apple AirPods Pro',
  },
  {
    id: '8',
    prizeNum: 4,
    detailName: 'OG訂製感恩禮包',
  },
  {
    id: '9',
    prizeNum: 5,
    detailName: '588元',
  },
  {
    id: '10',
    prizeNum: 6,
    detailName: '288元',
  },
  {
    id: '11',
    prizeNum: 7,
    detailName: '88元',
  },
  {
    id: '12',
    prizeNum: 8,
    detailName: '8元',
  },
]
